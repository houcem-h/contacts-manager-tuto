<template>
    <h1 class="text-center text-blue-700 text-4xl">
        Welcome to 3w-Contacts Application
    </h1>
</template>

<script>
    export default {
        
    }
</script>
