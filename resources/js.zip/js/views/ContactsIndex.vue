<template>
  <div>
      <ContactsList />
  </div>
</template>

<script>
import ContactsList from '../components/ContactsList'
export default {
  name: 'ContactsIndex',
  components: {
    ContactsList
  }
}
</script>

<style>

</style>